package External.services;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name="Banking_System")
public interface Banking_Services {

}
