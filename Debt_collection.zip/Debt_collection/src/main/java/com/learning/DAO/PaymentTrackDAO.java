package com.learning.DAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.learning.entity.PaymentTrack;

import lombok.RequiredArgsConstructor;

@Repository

public class PaymentTrackDAO {
	
	@Autowired
	private EntityManager em;
	
	public List<PaymentTrack> findPaymentTrackByMonthAndYear(int month, int year){
		
		CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
		CriteriaQuery<PaymentTrack> criteriaQuery = criteriaBuilder.createQuery(PaymentTrack.class);
		
		//select * from PaymentTrack
		Root<PaymentTrack> root = criteriaQuery.from(PaymentTrack.class);
		
		//prepare WHERE monthNo equals
		Predicate monthPredicate = criteriaBuilder.equal(root.get("monthNo"), month);
		
		//prepare WHERE year equals
		Predicate yearPredicate = criteriaBuilder.equal(root.get("year"), year);
		
		Predicate andPredicate = criteriaBuilder.and(monthPredicate,yearPredicate);
		
		//final query --> select * from PaymentTracker WHERE monthNO = 3 AND year = 2023
		
		criteriaQuery.where(andPredicate);
		
		TypedQuery<PaymentTrack> query = em.createQuery(criteriaQuery);
		return query.getResultList();

	}

	public List<PaymentTrack> findAllDefaulters() throws ParseException {
		
		LocalDate date = LocalDate.now();
		CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
		CriteriaQuery<PaymentTrack> criteriaQuery = criteriaBuilder.createQuery(PaymentTrack.class);
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
        Date date1 = simpleDateFormat.parse("2022-12-06");
        Date date2 = simpleDateFormat.parse("2022-12-05");
 
        System.out.println(date1.before(date2));
        System.out.println(date1.equals(date2));
        System.out.println(date1.after(date2));
		
		//select * from PaymentTrack
		Root<PaymentTrack> root = criteriaQuery.from(PaymentTrack.class);
		
		//prepare WHERE monthNo equals
		Predicate datePredicate = criteriaBuilder.lessThanOrEqualTo(root.get("paymentRecieveDate"), date);
		
		/*
		 * //prepare WHERE year equals Predicate yearPredicate =
		 * criteriaBuilder.equal(root.get("year"), year);
		 * 
		 * Predicate andPredicate = criteriaBuilder.and(monthPredicate,yearPredicate);
		 */
		
		//final query --> select * from PaymentTracker WHERE monthNO = 3 AND year = 2023
		
		criteriaQuery.where(datePredicate);
		
		TypedQuery<PaymentTrack> query = em.createQuery(criteriaQuery);
		return query.getResultList();
	}

}
