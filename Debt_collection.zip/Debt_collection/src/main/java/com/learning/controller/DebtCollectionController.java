package com.learning.controller;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.learning.DAO.PaymentTrackDAO;
import com.learning.entity.PaymentTrack;
import com.learning.repository.DebtCollectionRepository;
import com.learning.service.DebtCollectionService;

import java.text.SimpleDateFormat;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.List;
@CrossOrigin(origins="*")
@RestController
public class DebtCollectionController {
	
	@Autowired 
	private DebtCollectionService service;
	  
	@Autowired 
	private DebtCollectionRepository repository;
	  
	@Autowired 
	private PaymentTrackDAO paymentTrackDAO;
	 
	private static final Logger logger = LogManager.getLogger(DebtCollectionController.class);
	
	//create API Input is: PaymentTrack
	@PostMapping("/api/debtCollection/create") 
	public ResponseEntity<PaymentTrack> addPaymentTrack(@RequestBody PaymentTrack PaymentTrack) {
		ResponseEntity<PaymentTrack> status = null;
		try {
			service.savePaymentTrack(PaymentTrack);
			status = ResponseEntity.status(HttpStatus.CREATED).build();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			status = ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}

		return status;
	}

	@PostMapping("/addPaymentTracks")
	public ResponseEntity<List<PaymentTrack>> addPaymentTracks(@RequestBody List<PaymentTrack> PaymentTracks) {
		ResponseEntity<List<PaymentTrack>> status = null;

		try {
			service.savePaymentTracks(PaymentTracks);
			status = ResponseEntity.status(HttpStatus.CREATED).build();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			status = ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}

		return status;
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/api/debtCollection/listOfdefaulters")
	public List<PaymentTrack> findAllDefaulters() {
		List<PaymentTrack> defaulterList = new ArrayList<>();
		try {
			defaulterList = service.findAllBypaymentRecieveDateAfter();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return defaulterList;
     }

	
	@GetMapping("/api/debtCollection/pull/{monthNo}/{year}")
	public List<PaymentTrack> findPaymentTrackById(@PathVariable int monthNo, @PathVariable int year) {
		List<PaymentTrack> list = new ArrayList<>();
		try {
			list = service.findPaymentTrackByMonthAndYear(monthNo, year);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	 

	
	@GetMapping("/PaymentTrack/{id}")
	public PaymentTrack findPaymentTrackByID(@PathVariable int id) {
		return service.getPaymentTrackById(id);
	}
	@GetMapping("/api/debtCollection/pull")
	public List<PaymentTrack> findAllPaymentTracks() {
		List<PaymentTrack> list = new ArrayList<>();
		try {
			list = repository.findAll();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}
	 
	
	@PutMapping("api/debtCollection/update")
	public ResponseEntity<PaymentTrack> updatePaymentTrack(@RequestBody PaymentTrack paymentTrack) {
		ResponseEntity<PaymentTrack> status = null;
		try {
			service.updatePaymentTrack(paymentTrack);
        } catch (Exception e) {
			System.out.println(e.getMessage());
			status = ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}

		return status;
	}
	 
	 

}
