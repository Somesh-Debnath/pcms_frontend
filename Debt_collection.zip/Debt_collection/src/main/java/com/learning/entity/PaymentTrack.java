package com.learning.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PAYMENT_TRACK")
public class PaymentTrack {
	
	@Id
    @GeneratedValue
	@Column(name = "paymentTrackId")
    private int paymentTrackId;
	
	@Column(name = "loanAppId")
    private String loanAppId;
	
	@Column(name = "month_no")
    private int monthNo;
	
	@Column(name = "year_no")
    private int year;
	
	@Column(name = "status")
    private String status;
	
	@Column(name = "dueDateOfPayment")
    private Date dueDateOfPayment;
	
	@Column(name = "paymentRecieveDate")
    private Date paymentRecieveDate;
    
	public PaymentTrack() {
		
	}
	
	public PaymentTrack(int id, String loanAppId, int month, int year, 
			String status, Date dueDateOfPayment, Date paymentRecieveDate) {
		
		this.dueDateOfPayment = dueDateOfPayment;
		this.paymentRecieveDate = paymentRecieveDate;
		this.loanAppId = loanAppId;
		this.monthNo = month;
		this.year = year;
		this.paymentTrackId = id;
		
	}
	public int getPaymentTrackId() {
		return paymentTrackId;
	}
	public void setPaymentTrackId(int paymentTrackId) {
		this.paymentTrackId = paymentTrackId;
	}
	public String getLoanAppId() {
		return loanAppId;
	}
	public void setLoanAppId(String loanAppId) {
		this.loanAppId = loanAppId;
	}
	public int getMonthNo() {
		return monthNo;
	}
	public void setMonthNo(int monthNo) {
		this.monthNo = monthNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDueDateOfPayment() {
		return dueDateOfPayment;
	}
	public void setDueDateOfPayment(Date dueDateOfPayment) {
		this.dueDateOfPayment = dueDateOfPayment;
	}
	public Date getPaymentRecieveDate() {
		return paymentRecieveDate;
	}
	public void setPaymentRecieveDate(Date paymentRecieveDate) {
		this.paymentRecieveDate = paymentRecieveDate;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
    
    

}

