package com.learning.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.learning.entity.PaymentTrack;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public interface DebtCollectionRepository extends JpaRepository<PaymentTrack,String> {
	PaymentTrack findByloanAppId(String loanAppId);

	PaymentTrack findByPaymentTrackId(int paymentTrackId);

	List<PaymentTrack> findAllBypaymentRecieveDateAfter(Date paymentRecieveDate);
	
}


