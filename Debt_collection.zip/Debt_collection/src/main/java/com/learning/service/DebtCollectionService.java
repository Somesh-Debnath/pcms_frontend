package com.learning.service;

import com.learning.DAO.PaymentTrackDAO;
import com.learning.entity.PaymentTrack;
import com.learning.repository.DebtCollectionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class DebtCollectionService {

	@Autowired
	private DebtCollectionRepository repository;
	
	@Autowired 
	private PaymentTrackDAO paymentTrackDAO;

	public ResponseEntity savePaymentTrack(PaymentTrack PaymentTrack) {
		repository.save(PaymentTrack);
		return ResponseEntity.ok().build();
	}

	public List<PaymentTrack> savePaymentTracks(List<PaymentTrack> PaymentTracks) {
		return repository.saveAll(PaymentTracks);
	}

	@Query("Select c from PaymentTrack c")
	public List<PaymentTrack> getPaymentTracks() {
		return repository.findAll();
	}

	public PaymentTrack getPaymentTrackById(int id) {
		return repository.findByPaymentTrackId(id);
	}
	
	public List<PaymentTrack> findAllBypaymentRecieveDateAfter() {
		List<PaymentTrack> defaulterList = new ArrayList<>();
		try {
			defaulterList = (List<PaymentTrack>) repository.findAllBypaymentRecieveDateAfter
					(new SimpleDateFormat("yyyy-MM-dd").parse("2023-04-15")); 
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return defaulterList;
	}

	public List<PaymentTrack> findPaymentTrackByMonthAndYear(int monthNo, int year) {
		List<PaymentTrack> list = new ArrayList<>();
		try {
			list = paymentTrackDAO.findPaymentTrackByMonthAndYear(monthNo, year);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return list;
	}

	public ResponseEntity updatePaymentTrack(PaymentTrack paymentTrack) {
		ResponseEntity<PaymentTrack> status = null;
		try {
		PaymentTrack existingPaymentTrack = repository.findByloanAppId(paymentTrack.getLoanAppId());
		existingPaymentTrack.setStatus(paymentTrack.getStatus());
		existingPaymentTrack.setPaymentRecieveDate(paymentTrack.getPaymentRecieveDate());
		repository.save(existingPaymentTrack);
		status = ResponseEntity.ok().build();
		}catch (Exception e) {
			System.out.println(e.getMessage());
			status = ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
		return status;
		
	}

}
