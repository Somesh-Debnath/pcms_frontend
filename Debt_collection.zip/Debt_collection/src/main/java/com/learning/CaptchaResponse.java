package com.learning;

import java.util.List;

public class CaptchaResponse {

	
	private boolean success;
	private String challenge_ts;
	private String host_name;
	private float score;
	private String action;
	List<String> error_codes; 
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public List<String> getError_codes() {
		return error_codes;
	}
	public void setError_codes(List<String> error_codes) {
		this.error_codes = error_codes;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getChallenge_ts() {
		return challenge_ts;
	}
	public void setChallenge_ts(String challenge_ts) {
		this.challenge_ts = challenge_ts;
	}
	public String getHost_name() {
		return host_name;
	}
	public void setHost_name(String host_name) {
		this.host_name = host_name;
	}
	@Override
	public String toString() {
		return "CaptchaResponse [success=" + success + ", challenge_ts=" + challenge_ts + ", host_name=" + host_name
				+ ", score=" + score + ", action=" + action + ", error_codes=" + error_codes + "]";
	}
	
	
	
	
	
	
}
