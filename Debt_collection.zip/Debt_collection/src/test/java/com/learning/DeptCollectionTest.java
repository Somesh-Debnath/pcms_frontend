package com.learning;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.learning.DAO.PaymentTrackDAO;
import com.learning.entity.PaymentTrack;
import com.learning.repository.DebtCollectionRepository;
import com.learning.service.DebtCollectionService;

@RunWith(SpringRunner.class)
@SpringBootTest
class DeptCollectionTest {

	@Autowired
	private DebtCollectionService service;

	@MockBean
	private DebtCollectionRepository repository;
	
	@MockBean 
	private PaymentTrackDAO paymentTrackDAO;
	
	@Test
	public void savePaymentTrackTest() {
		PaymentTrack paymentTrack = new PaymentTrack(1, "123", 3, 2023, "not recieved", null, null);
		when(repository.save(paymentTrack)).thenReturn(paymentTrack);
		assertEquals(ResponseEntity.ok().build(), service.savePaymentTrack(paymentTrack));
	}

	
	@Test
	public void getPaymentTracksTest() {
		when(repository.findAll()).thenReturn(Stream.of(new PaymentTrack(1, "123", 3, 2023, "not recieved", null, null),
				new PaymentTrack(2, "124", 4, 2023, "not recieved", null, null)).collect(Collectors.toList())); 
	    assertEquals(2, service.getPaymentTracks().size());
		
	}

	@Test
	public void findAllBypaymentRecieveDateAftertest() {
		when(repository.findAllBypaymentRecieveDateAfter(null)).
		thenReturn(Collections.emptyList());
		assertEquals(0, service.findAllBypaymentRecieveDateAfter().size());
	}
	
	
	@Test
	public void updatePaymentTrackTest() {
		PaymentTrack paymentTrack = new PaymentTrack(1, "123", 3, 2023, "payement recieved", null, null);
		when(repository.findByloanAppId(paymentTrack.getLoanAppId())).thenReturn(paymentTrack);
		when(repository.save(paymentTrack)).thenReturn(paymentTrack);
		System.out.println(service.updatePaymentTrack(paymentTrack));
		assertEquals(ResponseEntity.ok().build(), service.updatePaymentTrack(paymentTrack));
	}
	 
	
	
	@Test
	public void findPaymentTrackByMonthAndYearTest() {
		int monthNo = 3;
		int year = 2023;
		when(paymentTrackDAO.findPaymentTrackByMonthAndYear(monthNo, year))
				.thenReturn(Stream
						.of(new PaymentTrack(1, "123", 3, 2023, "not recieved", null, null),
								new PaymentTrack(2, "124", 4, 2023, "not recieved", null, null))
						.collect(Collectors.toList()));
		assertEquals(2, service.findPaymentTrackByMonthAndYear(monthNo, year).size());
	}
	 

	
}
